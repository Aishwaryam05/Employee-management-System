package com.projectems.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor(staticName="build")
@Data
public class UserDTO {
    public UserDTO() {
		// TODO Auto-generated constructor stub
	}

	private Long id;

    @NotBlank
    private String username;

    @NotBlank
    private String password;

    private String role;

   
}
