package com.projectems.service;

import com.projectems.entities.User;

public interface UserService 
{
       User login(String username,String userPassword);

}
