package com.projectems.service;


import com.projectems.entities.Demo;

public interface DemoService {

	public Demo login(String demoUsername, String demoPassword);
}
